﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class clsItemDesc
    {
        /// <summary>
        /// Sets sItemCode in the clsItemDesc object
        /// </summary>
        public string sItemCode { get; set; }
        /// <summary>
        /// Sets sItemCode in the clsItemDesc ojbect
        /// </summary>
        public string sItemDesc { get; set; }
        /// <summary>
        /// Sets sCost in the clsItemDesc object
        /// </summary>
        public string sCost { get; set; }
    }
}
