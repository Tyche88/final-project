﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class clsLineItems
    {
        /// <summary>
        /// Sets sInvoiceNum in the clsLineItems ojbect
        /// </summary>
        public string sInvoiceNum { get; set; }
        /// <summary>
        /// Sets sLineItemNum in the clsLineItems object
        /// </summary>
        public string sLineItemNum { get; set; }
        /// <summary>
        /// Sets sItemCode in the clsLineItems object
        /// </summary>
        public string sItemCode { get; set; }
    }
}
