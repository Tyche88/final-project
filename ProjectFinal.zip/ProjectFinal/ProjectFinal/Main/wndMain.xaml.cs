﻿using ProjectFinal.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wndSearch;

namespace Main
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class wndMain : Window
    {
        #region Variables
        /// <summary>
        /// Create MainLogic object
        /// </summary>
        clsMainLogic clsMainLogic;
        /// <summary>
        /// Create listInvoice object
        /// </summary>
        List<clsInvoice> lstInvoice;
        #endregion
  
        #region MainWindow() - Constructor
        /// <summary>
        /// MainWindow() - Constructor
        /// </summary>
        public wndMain()
        {
            InitializeComponent();
            //instantiate clsMainLogic object
            clsMainLogic = new clsMainLogic();
            //gets list from clsMainLogic
            lstInvoice = clsMainLogic.lstInvoice;
            //bind data
            dataGridView.ItemsSource = clsMainLogic.GetInvoice();
        }
        #endregion

        #region Search - MenuItem_Click()
        /// <summary>
        /// Menu -> File -> Search - Opens "search" window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            //open "search" window. 

            //MessageBox.Show("Opens SEARCH window");

            MainWindow searchWindow = new MainWindow();
            searchWindow.ShowDialog();
        }
        #endregion
        #region Item - MenuItem_Click()
        /// <summary>
        /// Menu -> Edit -> Item - Opens "items" window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            //open "items" window. 

            //MessageBox.Show("Opens ITEMS window");

            wndItems items = new wndItems();
            items.ShowDialog();
        }
        #endregion
    }
}
