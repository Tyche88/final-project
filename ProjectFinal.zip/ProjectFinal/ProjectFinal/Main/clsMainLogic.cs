﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Main
{
    public class clsMainLogic
    {
        #region Variables
        /// <summary>
        /// Create class var named iRet
        /// </summary>
        public int iRet;
        /// <summary>
        /// Create clsSQL object
        /// </summary>
        clsMainSQL clsSQL;
        /// <summary>
        /// Create listInvoice object
        /// </summary>
        public List<clsInvoice> lstInvoice;
        /// <summary>
        /// Create clsDataAccess object
        /// </summary>
        clsDataAccess db;
        /// <summary>
        /// Create DataSet object
        /// </summary>
        public DataSet ds;
        #endregion
    
        #region Constructor
        /// <summary>
        /// Contructor
        /// </summary>
        public clsMainLogic()
        {
            clsSQL = new clsMainSQL();

            ds = new DataSet();
        }
        #endregion


        //1. database call
        //2. data access class
        //3. query database - clsSQL
        //4. pull data back
        //5. put into dataset
        //6. loop it around
        //7. Add to list.


        #region List<clsInvoice> GetInvoice()
        /// <summary>
        /// List to GetInvoice() data
        /// </summary>
        /// <returns></returns>
        public List<clsInvoice> GetInvoice()
        {
            List<clsInvoice> lstInvoice = new List<clsInvoice>();

            db = new clsDataAccess();
            iRet = 0;
            ds = db.ExecuteSQLStatement(clsSQL.LoadInvoiceData(), ref iRet);

            //1. if search is true
            //2. get selected InvoceID list (property)
            //3. focus on InvoiceID

            //1. if edit is true
            //2. get selected InvoiceID list (property)
            //3. focus on InvoiceID

            for (int i = 0; i < iRet; i++)
            {

                lstInvoice.Add(new clsInvoice
                {
                    sInvoiceNum = ds.Tables[0].Rows[i]["InvoiceNum"].ToString(),
                    sInvoiceDate = ds.Tables[0].Rows[i]["InvoiceDate"].ToString(),
                    sTotalCost = ds.Tables[0].Rows[i]["TotalCost"].ToString()
                });
            }
            return lstInvoice;
        }
        #endregion
        #region List<clsItemDesc> GetItemDesc()
        /// <summary>
        /// List to get GetItemsDesc() data
        /// </summary>
        /// <returns></returns>
        public List<clsItemDesc> GetItemDesc()
        {
            List<clsItemDesc> lstInvoice = new List<clsItemDesc>();

            db = new clsDataAccess();
            iRet = 0;
            ds = db.ExecuteSQLStatement(clsSQL.LoadItemDescData(), ref iRet);

            for (int i = 0; i < iRet; i++)
            {

                lstInvoice.Add(new clsItemDesc
                {
                    sItemCode = ds.Tables[0].Rows[i]["ItemCode"].ToString(),
                    sItemDesc = ds.Tables[0].Rows[i]["ItemDesc"].ToString(),
                    sCost = ds.Tables[0].Rows[i]["Cost"].ToString()
                });
            }
            return lstInvoice;
        }
        #endregion
        #region List<clsLineItems> GetLineItems()
        /// <summary>
        /// List to get GetLineItems() data
        /// </summary>
        /// <returns></returns>
        public List<clsLineItems> GetLineItems()
        {
            List<clsLineItems> lstInvoice = new List<clsLineItems>();

            db = new clsDataAccess();
            iRet = 0;
            ds = db.ExecuteSQLStatement(clsSQL.LoadLineItems(), ref iRet);

            for (int i = 0; i < iRet; i++)
            {

                lstInvoice.Add(new clsLineItems
                {
                    sInvoiceNum = ds.Tables[0].Rows[i]["InvoiceNum"].ToString(),
                    sLineItemNum = ds.Tables[0].Rows[i]["LineItemNum"].ToString(),
                    sItemCode = ds.Tables[0].Rows[i]["ItemCode"].ToString()
                });
            }
            return lstInvoice;
        }
        #endregion
    }
}
