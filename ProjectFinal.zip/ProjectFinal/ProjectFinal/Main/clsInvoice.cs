﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class clsInvoice
    {
        /// <summary>
        /// Used to set sInvoiceNum in the clsInvoice object
        /// </summary>
        public string sInvoiceNum { get; set; }
        /// <summary>
        /// Used to set sInvoiceDate in the clsInvoice object
        /// </summary>
        public string sInvoiceDate { get; set; }
        /// <summary>
        /// Used to set sTotalCost in the clsInvoice object
        /// </summary>
        public string sTotalCost { get; set; }
    }
}
